print("Введите число A:")
a = int(input())

print("Введите число B:")
b = int(input())

max = a if a < b else b

while max >= 0:
     if a % max == 0 and b % max == 0:
         break
     max = max - 1

print("Найбільший спільний дільник: ")
print(max)